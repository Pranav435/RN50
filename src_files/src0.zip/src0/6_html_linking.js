//This file shows how to link javaScript with html

function greet() {
alert("Hello")
}