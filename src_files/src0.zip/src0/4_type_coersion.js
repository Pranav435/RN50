//Type coersion

//Explicit coersion:
let life=42
life=String(life)

//implicit coersion
let life2=44444
life3+=""