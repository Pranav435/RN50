//Types
//Number:
const thisIsANumber=42;
const thisIsAnotherNumber=4.2
const thisIsABoolean=true
const thisIsAString="Hi, this is wonderful"
const thisDoesNotHaveValue=null
const thisIsUndefined=undefined
