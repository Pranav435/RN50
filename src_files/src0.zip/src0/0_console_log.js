console.log("Hello world")

// to run a javaScript file using node, cd into this folder, and then type node followed by the filename. For example, node 0_console_log.js
