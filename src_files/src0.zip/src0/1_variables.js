//This file looks at some variables

const firstName="Pranav";
const lastName='savla'
const life=42
console.log(firstName)
console.log(lastName)
console.log("The meaning of life is " , life)