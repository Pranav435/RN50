//This shows objects in a brief window

const myObj={}
myObj.name="Pranav"
myObj.age=14
myObj.greet=(){console.log("Hi")}
